from django.apps import AppConfig


class TechioappConfig(AppConfig):
    name = 'techioapp'
